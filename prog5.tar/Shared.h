#ifndef SHARED_H_
#define SHARED_H_
/*  Author: Troy Hughes */
struct point{
  int xPoint;
  int yPoint;
};

#endif
